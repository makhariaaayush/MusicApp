package com.example.recyclerview;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.Layout;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private ArrayList<String> nameList;
    private ArrayList<String> nameList1;
    private RVClickListener RVlistener;
    private int[] ima;
    private Context context;
    String b[];
    String s[];
    String si[];
//Passed values are collected here from MainActivity.java
    public MyAdapter(ArrayList<String> theList, ArrayList<String> theList1, String[] a, String[] song, String[] singer , int[] images, RVClickListener listener, Context ctx){
        nameList = theList;
        nameList1 = theList1;
        ima = images;
        b = a;
        s = song;
        si = singer;
        this.RVlistener = listener;
        context = ctx;
    }
//Context Menu Creation
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View listView = inflater.inflate(R.layout.rv_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listView, RVlistener);
        return viewHolder;
    }
//Binding View to Holder
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.name.setText(nameList.get(position));
        holder.name1.setText(nameList1.get(position));
        holder.image.setImageResource(ima[position]);
    }

    @Override
    public int getItemCount() {
        return nameList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnCreateContextMenuListener{

        public TextView name;
        public TextView name1;
        public ImageView image;
        private RVClickListener listener;
        private View itemView;


        public ViewHolder(@NonNull View itemView, RVClickListener passedListener) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.textView);
            name1 = (TextView) itemView.findViewById(R.id.textView1);
            image = (ImageView) itemView.findViewById(R.id.imageView);
            this.itemView = itemView;
            itemView.setOnCreateContextMenuListener(this); //set context menu for each list item (long click)
            this.listener = passedListener;
            itemView.setOnClickListener(this); //set short click listener
        }

        @Override
        public void onClick(View v) {
            Log.i("ON_CLICK", "Song Clicked");
            // listener.onClick(v, getAdapterPosition());
            Uri c = Uri.parse(b[getAdapterPosition()]);
            final Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(b[getAdapterPosition()]));
            context.startActivity(intent);
            Log.i("ON_CLICK", "URL Opening");
        }
//Used for inflating Context Menu
        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

            MenuInflater inflater = new MenuInflater(v.getContext());
            inflater.inflate(R.menu.context_menu, menu );
            menu.getItem(0).setOnMenuItemClickListener(onMenu);
            menu.getItem(1).setOnMenuItemClickListener(onMenu);
            menu.getItem(2).setOnMenuItemClickListener(onMenu);
        }

        private final MenuItem.OnMenuItemClickListener onMenu = new MenuItem.OnMenuItemClickListener(){
            @Override
            public boolean onMenuItemClick(MenuItem item){
                switch(item.getItemId()){
                    case R.id.menu1:
//Play Song
                        Log.i("ON_CLICK", "Song Played on Youtube");
                        Intent intent1 = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(b[getAdapterPosition()]));
                        context.startActivity(intent1);
                        break;
                    case R.id.menu2:
//Song Wiki
                        Log.i("ON_CLICK", "Song Wikipedia Opening");
                        Intent intent2 = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(s[getAdapterPosition()]));
                        context.startActivity(intent2);
                        break;
                    case R.id.menu3:
//Singer Wiki
                        Log.i("ON_CLICK", "Singer Wikipedia Opening");
                        Intent intent3 = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(si[getAdapterPosition()]));
                        context.startActivity(intent3);
                        break;
                }
                return true;
            }
        };
    }
}
