package com.example.recyclerview;

import android.view.View;

public interface RVClickListener {

    public void onClick(View view, int position);
}
