package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> myList;
    ArrayList<String> myList1;
    String a[];
    String song[];
    String singer[];
    int images[] = {R.drawable.better, R.drawable.dynamite, R.drawable.hello, R.drawable.rockstar, R.drawable.sorry, R.drawable.starboy, R.drawable.sugar, R.drawable.summerch, R.drawable.sunflower, R.drawable.thunderch};
    RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView nameView = (RecyclerView) findViewById(R.id.recycler_view);
        rv = nameView;
//Storing Song names in an array
        List<String> names = Arrays.asList("Better", "Dynamite", "Hello", "Rockstar", "Sorry", "Starboy", "Sugar",
                "Summer", "Sunflower", "Thunder");
//Storing Singer names in an array
        List<String> names1 = Arrays.asList("Khalid", "Taio Cruz", "Adele", "Post Malone", "Justin Beiber", "The Weekend", "Maroon 5",
                "Calvin Harris", "Post Malone", "Imagine Dragons");

        myList = new ArrayList<>();
        myList.addAll(names);
        myList1 = new ArrayList<>();
        myList1.addAll(names1);
        a = getResources().getStringArray(R.array.a);
        song = getResources().getStringArray(R.array.song);
        singer = getResources().getStringArray(R.array.singer);
        RVClickListener listener = (view, position) -> {
            TextView name = (TextView) view.findViewById(R.id.textView);
            Toast.makeText(this, name.getText(), Toast.LENGTH_SHORT).show();
        };
//used for passing adapter values to MyAdapter.java
        MyAdapter adapter = new MyAdapter(myList, myList1, a, song, singer, images, listener, this);
        nameView.setHasFixedSize(true);
        nameView.setAdapter(adapter);
        nameView.setLayoutManager(new LinearLayoutManager(this)); //use this line to see as a standard vertical list
        rv.setLayoutManager(new LinearLayoutManager(this)); //use this line to see as a standard vertical list
    }

//used to inflate the options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.ListMenu:
//List View Layout
                Log.i("ON_CLICK", "List Layout");
                rv.setLayoutManager(new LinearLayoutManager(this));
                return true;
            case R.id.GridMenu:
//Grid View layout
                Log.i("ON_CLICK", "Grid Layout");
                rv.setLayoutManager(new GridLayoutManager(this, 2));
                return true;
            default:
//Default Case
                return super.onOptionsItemSelected(item);
        }
    }
}


